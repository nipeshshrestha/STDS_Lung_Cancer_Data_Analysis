# exploratory
Learnr tutorials for exploratory analysis and basic descriptive statistics

These are a series of four tutorials writtin in learnr to teach undergraduates basic descriptive statistics and exploratory data analysis. I'm making these avilable for anyone who wants to use them. They can be compiled easily into an R package in RStudio which means that, if a recent release of RStudio is used, they will appear in the "tutorials" pane when the package is loaded.

This work is licensed under a Creative Commons Attribution-NonCommercial 4.0 International License.
