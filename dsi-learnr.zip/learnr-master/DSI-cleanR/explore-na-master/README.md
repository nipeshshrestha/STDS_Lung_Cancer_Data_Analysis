# explore-na
Exploring NAs in a small rodent dataset
