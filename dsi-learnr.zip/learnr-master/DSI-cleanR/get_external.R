
# And fork of excellent interactives around NA
download.file("https://github.com/allisonhorst/explore-na/archive/refs/heads/master.zip", destfile = here::here("DSI-cleanR/na.zip"))

unzip(zipfile = here::here("DSI-cleanR/na.zip"), exdir = here::here("DSI-cleanR/"))

