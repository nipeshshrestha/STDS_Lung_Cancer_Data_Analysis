# learnr
Interactive Tutorials with R Markdown

Mostly modified from the fantastic examples provided, and (openly licensed) materials provided by others (with thanks to them). 

Tutorials are run ith `runlearnr` function, which appends some grading logic and submission content to the learnr tutorials and then runs the files interactively in a local session.
